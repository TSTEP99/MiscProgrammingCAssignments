#include <stdlib.h>
#include <stdio.h>
#include <math.h>


int is_prime(int n);

int print_semiprime(int a, int b);


int main(){   
   int a, b;
   printf("Input two numbers: ");
   scanf("%d %d", &a, &b);
   if( a <= 0 || b <= 0 ){
     printf("Inputs should be positive integers\n");
     return 1;
   }

   if( a > b ){
     printf("The first number should be smaller than or equal to the second number\n");
     return 1;
   }

   // TODO: call the print_semiprimes function to print semiprimes in [a,b] (including a and b)

   print_semiprime(a, b);
   printf("\n");
}


/*
 * TODO: implement this function to check the number is prime or not.
 * Input    : a number
 * Return   : 0 if the number is not prime, else 1
 */

int is_prime(int n){
	
		if(n<2){
			return 0;	//returns not prime if 0 or 1
		}
		
		float x= (float) n; //does typecasting to allow for sqrt to be used
		float k=2; // starts the division at 2
		
		for(;k<=n-1;k++){
			
			if((((int)n)%((int) k)==0)){
				return 0;
			}
			
			//If the division yields a factor it returns not a prime
			
		}
		
		return 1; //returns prime if no division happened
}


/*
 * TODO: implement this function to print all semiprimes in [a,b] (including a, b).
 * Input   : a, b (a should be smaller than or equal to b)
 * Return  : 0 if there is no semiprime in [a,b], else 1
 */

int print_semiprime(int a,int b){
	
	int n;
	int exists=0;
	
	
	for(n=a;n<=b;n++){ //loops through entire range
		int k;
		//loops range of number
		for(k=2;k<n;k++){
			if( is_prime(k) && is_prime(n/k)&& n%k==0){ //if the k and its factor are both prime prints the number and sets exists
				printf("%d ",n);
				exists=1;
				break;
			}
		}
	}
	
	return exists; //returns whether or not it exists
}


