#include "prime.h"
#include <math.h>
int is_prime(int n){

		
		if(n<2){
			return 0;	//returns not prime if 0 or 1
		}
		
		float x= (float) n; //does typecasting to allow for sqrt to be used
		float k=2; // starts the division at 2
		
		for(;k<=sqrt(x);k++){
			
			if((((int)n)%((int) k)==0)){
				return 0;
			}
			
			//If the division yields a factor it returns not a prime
			
		}
		
		return 1; //returns prime if no division happened

}

