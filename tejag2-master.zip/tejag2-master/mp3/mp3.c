#include <stdio.h>

/*
	the program I created calculates the row of pascal's trianglw
	by always printing 1 for valid inputs then using a forloop to print 
	the rest of the inputs by first multiplying by row+1-i then divding by
	i where i is a number for 1 to row. I chose this approach over multiplying by
	a fraction due to the limitations of the unsigned long data type.
	I also added a check for invalid inputs that returns 1 if the row number is less than 0
	partners: kalpitf2,marca4

*/
int main(){
	
	int row; //initializes variable for row
	
	printf("Enter the row column : ");
	scanf("%d",&row); // gets input for row number

	
	unsigned long product=1; //initlizaes first term of each row

	printf("%lu ",product); //prints first term of each row
	
	int i; //makes variable to loop through row
	
	for(i=1;i<=row;i++){
			product*=(row+1-i); // multiplies by (row+1-i)/i
			product/=i;
			
			printf("%lu ",product); //prints out the product
	}

	return 0;
	
}
