/* Code to simulate rolling three six-sided dice (D6)
 * User first types in seed value
 * Use seed value as argument to srand()
 * Call roll_three to generate three integers, 1-6
 * Print result "%d %d %d "
 * If triple, print "Triple!\n"
 * If it is not a triple but it is a dobule, print "Double!\n"
 * Otherwise print "\n"
 */

#include<stdio.h>
#include <stdlib.h>
#include <time.h>
#include "dice.h"

int main(){
	int count[6]={0,0,0,0,0,0};	
	int n;	
	printf("Enter Seed:\n");
	scanf("%d",&n);

	srand(n);
	int one;
	int twice;
	int three;
	roll_three(&one,&twice,&three);

	count[one-1]+=1;
	count[twice-1]+=1;
	count[three-1]+=1;

	printf("%d %d %d\n",one,twice,three);

	int max=1;

	int i;
	for(i=0;i<6;i++){
		if(max<count[i]){
			max=count[i];		
		}
	}

	switch(max){
		case 2: printf("DOUBLE!!!\n");
			break;
		case 3:printf("TRIPLE!!!\n");
			break;
	}

}


