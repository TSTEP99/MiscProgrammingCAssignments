#include <stdio.h>
#include <math.h>

#define M_PI 3.14159265358979323846

/*
 * main
 *  DESCRIPTION: compute a set of points of a function and print the results
 *  INPUTS: console (int, float float) -- equation related constants
 *  OUTPUTS: console (x, f(x)) -- sequence of values to be printed
 *  RETURN VALUE: 0
 *  SIDE EFFECTS: none
 */
int main()
{
    // Declare variables
int n;
double omega1;
double omega2;

    // Prompt user for input
printf("Enter the values of n, omega1, and omega2 in that order\n");
scanf("%d %lf %lf",&n,&omega1,&omega2);

    // Get user input

    // Compute function output
    /* for i from 0 to n-1
     *     compute and print xi and f(xi)
     *     use sin() function from math.h
     */
int i;
for(i=0;i<n;i++){
	double x=i*M_PI/n;
	printf("(%lf,%lf)\n",x,sin(omega1*x)+.5*sin(omega2*x));
}


    return 0;
}

